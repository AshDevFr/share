(function() {
  'use strict';

  angular
    .module('blogularApp-components', []);
})();
